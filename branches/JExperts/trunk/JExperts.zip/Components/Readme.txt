This package is a set of components I use internally... The most
used is the JeXmlParser. The component is not XML compliant at
all (this is why I haven't published it), but this is really
a great component!!!!

It is used in JExperts...